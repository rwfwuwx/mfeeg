function [fft_coef,spec_am_raw,spec_am_norm,spec_phase,spec_freq] = mf_spec(sig,fs,am_type,phase_type,FreqNorm_points,FreqNorm_method,plot_option)
%[fft_coef,spec_am_raw,spec_am_norm,spec_phase,spec_freq] = mf_spec(sig,fs,am_type,phase_type,FreqNorm_points,is_plot)
%   perform spectrum analyses, including amplitude and phase.
%   it also adds an option to plot in time and frequency(amplitude and phase) domain, which is useful for testing on sig. 
%Usage
%   [fft_coef,spec_am_raw,spec_am_norm,spec_phase,spec_freq] = mf_spec(sig,fs,am_type,phase_type,FreqNorm_points,is_plot)
%Inupts
%   sig -- a vector
%   fs -- sampling rate
%   am_type -- returned amplitude type.one of the following
%       'amplitude': abs(coef) (default)
%       'power': abs(coef).^2
%       'db':10*log10(abs(coef).^2)
%       This is the same as E_type in other function. here call it amplitude for fft spectrum convention.
%   phase_type
%       'radius' or 'degree' (default). -pi ~ pi or -180 ~ 180.
%   FreqNorm_points --- This only for amplitude, not for phase.
%       for each freq point, its value is relative to the average of the values from FreqNorm_points neighboring freq points, 
%           including both left and right neighbors.
%       For whole spec_freq, the normalization is only performed on the beginning, i.e., from 0 Hz (since the maximal freqencies is not the interests).
%   FreqNorm_method
%       1: subtraction. see Nozaradan 2011. for srssep.
%       2. devide. the so-called SNR. see Norcia 2015. for ssep.
%       3: smooth. for resting
%   plot_option ---  
%       []: not plot
%       1: spec_am_raw 
%       2: spec_am_norm
%       3: spec_am_raw, but ignor the first 10 freq points, to avoid the noise at the begining freqs
%       when plot, plot time and frequency domain.
%Outputs
%   fft_coef --- (for backup, typically not use directly)
%   spec_am_raw, spec_am_norm,spec_phase --- frequency spectrum: amplitude, phase
%       return one side, e.g., 1000 Hz fs, returned frequency range is 0-500 Hz.
%       frequency resolution is fs / sample number (i.e., signal length in sample number).
%   spec_
%   spec_freq --- One side freq of spec. More easily speaking, use this as the freq axis when plotting spec. 
%
% Todo
%   the results of db is abnormal for FreqNorm_method == 2 or 3. handle later.
% Update history
%   2022-11-23 
%       add FreqNorm_method
%       minor updates to be more clear
%   2020-10-19 add normalization of neighbor freq
%   2020-10-18 modify from mf_fft_plot
%       1. add phase
%       2. rewite to be more clear about: 
%           Normalize by /len_sig; 
%           *2 to account for am of the other side
%       3. mf_fft_plot -> mf_spec
%           % make it the fundermental low-level function, as the basis for high-level functions
% Ref of fft implementation
%   help fft; Fast Fourier Transform (FFT), search in Matlab documentation
%       
%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com    
%-------------------------------------------------------------------------

if (nargin ~= 7)
    disp('mf_spec requires 7 input arguments!')
	return
end

sig = sig(:)'; %convert to row vector
len_sig = length(sig);
T = 1/fs; % period

% --- time axis
t=(0:len_sig-1)*T; % Say, time is from 0 s.
% sig = detrend(sig);
% |--- fft transform ---|
fft_coef = fft(sig);

% --- amplitude
switch am_type 
    case 'amplitude'
        am_twoside = abs(fft_coef)/len_sig; % as in fft doc
        % am_twoside = abs(fft_coef/len_sig); % as in help fft
    case 'power'
        am_twoside = (abs(fft_coef).^2)/len_sig;
    case 'db'
        am_twoside = 10*log10( abs(fft_coef).^2 )/len_sig;
        %am_twoside = 10*log10( abs(fft_coef).^2 /len_sig); % same as above, except scale
        %am_twoside = 10*log10(abs(fft_coef)) /len_sig; % % same as above, except scale
        %am_twoside = log(abs(fft_coef)) /len_sig; % % same as above, except scale
end
% about Normalize by /len_sig
%   this normalization is only for amplitude, not for phase

am_oneside = am_twoside(1:floor(len_sig/2)+1)*2; % 1. *2 to account for am of the other side. 2. use floor, in case len_sig is not even
% about *2 to account for am of the other side
%   this is needed only for amplitude, not for phase

spec_am_raw = am_oneside;

% amplitude normalization
%   about:
%       this normalization is kind of smooth, i.e., peak->platform, do not use too much. 2 ~ 3 should work for most case. 
%           otherwise, identifying peak would be non-sense. This certainly
%           depends on data points and freq resolution, check results to choose appropriate number.
%       !!! need to include the central peak itself, otherwise, a peak  would -> double peak, other than platform; 
%           which does not make sense.
%       %   also note that this is not removing mean: it works as smoothing, but not subtraction overal mean.
spec_am_norm = zeros(1,length(am_oneside));

separate_point = 1; % i.e., not including the freq itself
%
for ii=1:length(am_oneside)
    if ii<=FreqNorm_points 
        %spec_am_norm(ii) = mean(am_oneside([ii+1:ii+FreqNorm_points])); % use right side. later add more complicated left side.
        if FreqNorm_method==1
            spec_am_norm(ii) = am_oneside(ii) - mean(am_oneside([ii+separate_point:ii+FreqNorm_points])); 
        end
        if FreqNorm_method==2
            spec_am_norm(ii) = am_oneside(ii) / mean(am_oneside([ii+separate_point:ii+FreqNorm_points])); 
        end
        if FreqNorm_method==3
            spec_am_norm(ii) = mean(am_oneside([ii:ii+FreqNorm_points])); % for smooth, including itself
        end
    end
    if ii>FreqNorm_points && ii<(length(am_oneside)-FreqNorm_points)
        %spec_am_norm(ii) = mean(am_oneside([ii-FreqNorm_points:ii-1,ii+1:ii+FreqNorm_points]));
        if FreqNorm_method==1
            spec_am_norm(ii) = am_oneside(ii) - mean(am_oneside([ii-FreqNorm_points:ii-separate_point,ii+separate_point:ii+FreqNorm_points]));
        end
        if FreqNorm_method==2
            spec_am_norm(ii) = am_oneside(ii) / mean(am_oneside([ii-FreqNorm_points:ii-separate_point,ii+separate_point:ii+FreqNorm_points]));
        end
        if FreqNorm_method==3
            spec_am_norm(ii) = mean(am_oneside([ii-FreqNorm_points:ii+FreqNorm_points]));
        end
    end
    if ii>=(length(am_oneside)-FreqNorm_points)
        %spec_am_norm(ii) = mean(am_oneside([ii-FreqNorm_points:ii-1]));% use left side. later add more complicated left side.
        if FreqNorm_method==1
            spec_am_norm(ii) = am_oneside(ii) - mean(am_oneside([ii-FreqNorm_points:ii-1]));
        end
        if FreqNorm_method==2
            spec_am_norm(ii) = am_oneside(ii) / mean(am_oneside([ii-FreqNorm_points:ii-1]));
        end
        if FreqNorm_method==3
            spec_am_norm(ii) = mean(am_oneside([ii-FreqNorm_points:ii]));
        end
    end
end
%}


% --- phase
phase_twoside = angle(fft_coef); % between -pi and pi
%phase_twoside = unwrap(angle(fft_coef)); % not necessary and give extra large values. check more later

if phase_type == 'degree'
    phase_twoside = phase_twoside*180/pi;
end

phase_oneside = phase_twoside(1:floor(len_sig/2)+1);
spec_phase = phase_oneside;

% --- freq axis
f_oneside = fs/len_sig*(0:(len_sig/2)); % one side frequency, before Nyquist frequency 
% f_oneside = fs/2*linspace(0,1,(len_sig/2+1)); % same as the above line
spec_freq = f_oneside;

% --- plot
if ~isempty(plot_option)
    % time
    subplot(311),plot(t,sig);
    title('time series');
    xlabel('time (second)');
    
    % amplitude
    if plot_option == 1
        subplot(312),plot(spec_freq,spec_am_raw);
    end
    if plot_option == 2
        subplot(312),plot(spec_freq,spec_am_norm);
    end
    if plot_option == 3
        subplot(312),plot(spec_freq(11:end),spec_am_raw(11:end));
    end
    if plot_option == 4
        subplot(312),plot(spec_freq(11:end),spec_am_norm(11:end));
    end
    title('amplitude spectrum');
    xlabel('frequency (Hz)');
    
    % phase
    subplot(313),plot(spec_freq,spec_phase);
    title('phase spectrum');
    xlabel('frequency (Hz)');
end

%zoom on;

