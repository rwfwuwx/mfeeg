clear;

load GSN-HydroCel-128;
pos_tmp = lay.pos;
pos_tmp = pos_tmp(4:131,:);

%figure; scatter(pos_tmp(:,1),pos_tmp(:,2));

% --- x 
% move x range from (-0.5,0.5)-> (0,1)
pos_tmp(:,1) = pos_tmp(:,1)+0.5;
%figure; scatter(pos_tmp(:,1),pos_tmp(:,2));

% scale x range from (0,1)-> (0,1,0.9)
pos_tmp(:,1) = pos_tmp(:,1)*0.8+0.1;
%figure; scatter(pos_tmp(:,1),pos_tmp(:,2));

% --- y 
% move y range from (-0.5,0.5)-> (0,1)
pos_tmp(:,2) = pos_tmp(:,2)+0.5;
%figure; scatter(pos_tmp(:,1),pos_tmp(:,2));

% scale y range from (0,1)-> (0,1,0.9)
pos_tmp(:,2) = pos_tmp(:,2)*0.8+0.1;
%figure; scatter(pos_tmp(:,1),pos_tmp(:,2));

egi_ch128_pos_2D = pos_tmp;
save egi_ch128_pos_2D egi_ch128_pos_2D;

% display with mfeeg to confirm
load egi_ch128_pos_2D;
load egi_ch128_label;
mf_topo2D(egi_ch128_pos_2D,[1:128],[1:128],zeros(1,128),1,[]);
