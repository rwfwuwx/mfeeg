function y = mf_rawAMEnv(rawdata)
%mf_rawAMEnv      return amplitude envelope of rawdata
%Usage
%   y = mf_rawAMEnv(rawdata)
%Todo
%   add option later
%Update hisoty
%   2020-10-16 written

%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com     
%-------------------------------------------------------------------------

if nargin~=1
    disp('mf_rawAMEnv requires 1 input arguments!')
	return
end

[m,n] = size(rawdata);
y = zeros(m,n);

for i=1:n
     y(:,i) = envelope( rawdata(:,i)' )';
end

