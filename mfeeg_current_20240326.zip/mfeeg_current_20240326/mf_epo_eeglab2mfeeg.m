function [rawdata]=mf_epo_eeglab2mfeeg(file_path,file_name)

EEG = pop_loadset('filename',file_name,'filepath',file_path);
%transposition  <elec��samplepoints��epochs> to  <epochs��samplepoints��elec>
rawdata=permute(EEG.data,[3 2 1]);
disp('  end transposition');

end