function [cm_coef,cm_p] = mf_rawconnect(rawdata,connect_type,ch_include)
%mf_rawconnect      return connectivity matrix
%Usage
%   [cm_coef,cm_p] = mf_rawconnect(rawdata,connect_type,ch_include)
%Input
%   connect_type
%       1: pearson correlation
%       2: partrial pearson correlation
%       ... add later
%   ch_include, can be
%       whole brain, excluding EOG
%       or, sub brain regions, as interested
%Update history
%   2021-12-09 update ch_include for source level. [] for all ch/source.
%   2020-10-21 written
%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com     
%-------------------------------------------------------------------------

if nargin~=3
    disp('mf_rawconnect requires 3 input arguments!')
	return
end

if isempty(ch_include)
    ch_include = 1:size(rawdata,2);
end

rawdata = rawdata(:,ch_include);

if connect_type == 1
    [cm_coef,cm_p] = corr(rawdata); 
end

if connect_type == 2
    [cm_coef,cm_p] = partialcorr(rawdata); 
end
