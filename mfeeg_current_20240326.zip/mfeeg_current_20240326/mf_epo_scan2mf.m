function epo_mf = mf_epo_scan2mf(epo_scan,trial_num,trial_len,ch_num)
% mf_epo_scan2mf 	convert a epo file of neuroscan 4.3 to a epo file of mfeeg.
%   only do epoch using scan, or else can't remove wrong trials.
%   (Traditionally, neuroscan name epo as eeg).
% Usage
%	epo_mf = mf_epo_scan2mf(epo_scan,trial_num,trial_len,ch_num)
% Input
%	epo_scan -- a dat file converted from epo file of neuroscan.
%		*.eeg is eeg file of neuroscan,before been transfered to 
%		mf_eeg which need to be converted to *.dat using scan.
%       !note,epo_scan is a filename(a string),for instance,the name
%       of the data file are epo_scan.dat,you should type
%       epo_mf = mf_epo_scan2mf('epo_scan.dat');
%		convert parameters are:
% Output
%	epo_mf -- a mat file.it is a 3-D matrix,1d-trial;2d-sample point
%		3d-electrode.

%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify
% Welcome to find bugs,propose improvements, and discuss with author
%
% wu xiang     http://mail.ustc.edu.cn/~rwfwu/mfeeg/mfeeg.html
%              rwfwu@ustc.edu or rwfwu@yahoo.com.cn    
%-------------------------------------------------------------------------

if nargin~=4
    disp('mf_epo_scan2mf requires 4 input arguments!')
	return
end

fid_r = fopen(epo_scan,'r');

epo_mf = zeros(trial_num,trial_len,ch_num);

ch = 1;
trial = 1;
while ~feof(fid_r)
    line = fgets(fid_r);
    line = str2num(line);
    epo_mf(trial,:,ch) = line;
    ch = ch + 1;
    if ch == ch_num + 1
        ch = 1;
        trial = trial + 1;
    end
end
 
fclose(fid_r);
