function [eeg_raw_spec_am_raw,eeg_raw_spec_am_norm,eeg_raw_spec_phase,eeg_raw_spec_freq] = mf_rawspec(rawdata,fs,am_type,phase_type,FreqNorm_points,FreqNorm_method)
%mf_rawspec      perform spec analysis on rawdata.
%Usage
%   [eeg_raw_spec_am_raw,eeg_raw_spec_am_norm,eeg_raw_spec_phase,spec_freq] = mf_rawspec(rawdata,fs,am_type,phase_type,FreqNorm_points)
%   see further detials in mf_spec.
%Update hisoty
%   2022-01-23 add FreqNorm_method, see mf_spec.
%   2020-10-18 written

%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com     
%-------------------------------------------------------------------------

if nargin~=6
    disp('mf_rawspec requires 6 input arguments!')
	return
end

[m,n] = size(rawdata);
y = zeros(m,n);

% get freq
sig = rawdata(:,1)';
[t,t,t,t,eeg_raw_spec_freq] = mf_spec(sig,fs,am_type,phase_type,FreqNorm_points,FreqNorm_method,[]);

% initialize spec_am, spec_phase
eeg_raw_spec_am_raw = zeros(n,length(eeg_raw_spec_freq));
eeg_raw_spec_am_norm = zeros(n,length(eeg_raw_spec_freq));
eeg_raw_spec_phase = zeros(n,length(eeg_raw_spec_freq));

% calculate
for ii=1:n
      [t,eeg_raw_spec_am_raw(ii,:),eeg_raw_spec_am_norm(ii,:),eeg_raw_spec_phase(ii,:),t] = mf_spec(rawdata(:,ii)',fs,am_type,phase_type,FreqNorm_points,FreqNorm_method,[]);
end

