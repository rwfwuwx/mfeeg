
function [rawdata,ecd]= mf_easy2raw(easy_path,easy_filename)
% Load the *.easy file
    data = load([easy_path easy_filename]) ;
    % Define the time axis
    time = data(:,end) ; % milliseconds Unix Time
    time = time - time(1) ; % set clock to zero (first sample)
    time = time / 1000 ; % change time units to seconds
    % Define data (Enobio 8)
    rawdata = data(: ,1:8)/1e3 ; % Voltage in nanoVolts (nV)----to % data is now in uV
    ecd(:,1) = data(: ,9) ; % Markers info
    ecd(:,2) = [1:length(ecd(:,1))]';
%     save rawdata rawdata
%     save ecd ecd
end