function plv = mf_eposync_across2time(epo1,epo2,ncw_init,freq,fs,is_vary_ncw,ncw_step)
% mf_eposync_across2time	calculates sync between two epos that are at 2 different times.
%   
% Usage
%   plv = mf_eposync_across2time(epo1,epo2,ncw_init,freq,fs,is_vary_ncw,ncw_step)
% Input
%   epo1,epo2 -- two epo at different times.(has to be the same in sizes)
%   ncw_init,freq,fs,is_vary_ncw,ncw_step -- see mf_epotf.
% Output 
%	plv -- phase locking value across two epos that are at 2 different times .
%		

%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com    
%-------------------------------------------------------------------------

if nargin~=7
    disp('mf_eposync_across2time requires 7 arguments!');
    return;
end

[m,n,o] = size(epo1);

samp_period = 1/fs;
freq_num = length(freq);

plv = zeros(freq_num,n,o);

for ii = 1:o
    fprintf('%d ',ii);
    if mod(ii,16) == 0 | ii==o
        fprintf('\n');
    end
    
    for jj = 1:m
        coef1 = mf_tfcm( epo1(jj,:,ii),ncw_init,freq,fs,is_vary_ncw,ncw_step,'coef' );
        coef2 = mf_tfcm( epo2(jj,:,ii),ncw_init,freq,fs,is_vary_ncw,ncw_step,'coef' );
        
        %purely complex part of ch1
        cp1 = coef1;
        zero = find( abs(cp1)==0 );
        cp1(zero) = 1;
        cp1 = cp1./abs(cp1);
        cp1(zero) = 0;
        
        %purely complex part of ch2
        cp2 = coef2;
        zero = find( abs(cp2)==0 );
        cp2(zero) = 1;
        cp2 = cp2./abs(cp2);
        cp2(zero) = 0;
        
        %purely complex part of (angle of ch1 - angle of ch2)
        zero = find( abs(cp2)==0 );
        cp2(zero) = 1;
        tmp_plv = cp1./cp2; %angle 1 - angle 2
        tmp_plv(zero) = 0;
        
        plv(:,:,ii) = plv(:,:,ii) + tmp_plv;
    end
    
    plv(:,:,ii) = abs(plv(:,:,ii)/m);
end

