function raw_ConnectIndex = mf_raw_ConnectIndexTS(rawdata,connect_type,ch_include,connect_index,moving_window,moving_step)
%mf_rawconnect      return time series of connectivity index
%Usage
%   raw_ConnectIndex = mf_raw_ConnectIndexTS(rawdata,connect_type,ch_include,connect_index,moving_window,moving_step)
%Input
%   connect_type, ch_include --- same as mf_rawconnect
%   connect_index
%       1. connectivity strength
%           ignor positive and negative value
%       ... add later
%   moving_window (in sample points) 
%       use even number, to avoid unnecessary complexity
%   moving_step (in sample points)
%       currently use 1, later handle further details
%Update history
%   2020-10-21 written
%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Xu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com     
%-------------------------------------------------------------------------

if nargin~=6
    disp('mf_raw_ConnectIndexTS requires 6 input arguments!')
	return
end

rawdata = rawdata(:,ch_include);

[m,n] = size(rawdata);
raw_ConnectIndex = zeros(1,m);

for ii=1:moving_step:m
    % cut data
        % currently, same handling of left and right side as mf_spec
    if ii<=(moving_window/2)
        tmp_data = rawdata( ( ii:(ii+moving_window/2) ),: );
    end
    if ii>(moving_window/2) && ii<(m-(moving_window/2))
        tmp_data = rawdata( ( (ii-moving_window/2):(ii+moving_window/2) ),: );
    end
    if ii>=(m-(moving_window/2))
        tmp_data = rawdata( ( (ii-moving_window/2):ii ),: );
    end
    
    % connect
    if connect_type == 1
        [cm_coef,cm_p] = corr(tmp_data);
    end
    if connect_type == 2
        [cm_coef,cm_p] = partialcorr(tmp_data);
    end
    
    % connect index
    if connect_index==1
        cm_index = mean(mean(abs(cm_coef)));
    end
    
    raw_ConnectIndex(ii) = cm_index;
    
end

