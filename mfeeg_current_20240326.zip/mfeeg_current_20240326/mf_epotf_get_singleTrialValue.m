function tfValue = mf_epotf_get_singleTrialValue(epo,ncw_init,freq_interest,fs,is_vary_ncw,ncw_step,E_type,time_interest,tf_type,ch_interest,base,norm_method)
% mf_epotf_singleTrialValue get single trial values of a tf window.
% Usage
%   [tfValue] = mf_epotf_get_singleTrialValue(epo,ncw_init,freq_interest,fs,is_vary_ncw,ncw_step,E_type,time_interest,tf_type,base,norm_method)
% Input
%	from epo to E_type --- see mf_epotf. freq now refers to interested freq window
%	time_interest --- interested time window
%   tf_type --- 1:tfboth; 2 tfnpltwo
%   ch_interest --- interested ch, can be one or more. 
%	base, norm_method -- see mf_tfnorm
% Output
%   mean value of the tf window. each column contains the values of a ch_interest.
% Description
%   This is for single subject stat on single trials.
%       After perform mf_epotf, with normalization; use this function to get the value of interested tf window, of single trials.
%       use the same parameters as run mf_epotf, and mf_tfnorm.
%   A comparison between erp and ertf, for single trial analysis.
%       --- erp: single trial data structure is actually epo. thus get single trial data
%       from epo, although the erp processing steps are included, as epo_before_erp.
%       --- tf: tf data is large. the tf data structure including trial
%       will be 4-D, which is huge.
%       Therefore, for tf, instead get the single trial data stucture
%       before tf, here, re-run mf_epotf, but get the value of interested
%       tf window, as well as interested ch.
%   further Note 1: the returned value is already normalized; since this func serves as a post analysis after mf_epotf, and mf_tfnorm.
%   further Note 2: tfpl, tfnplone, plf, does not have single trial data. 
%
% update history
%   2020-06-02 update
%   2020-05-07 initially written
%
%-------------------------------------------------------------------------
% mfeeg is free and open source,under GPL
% Hope it will be useful to you but without any warranty
% You can use,distribute,modify it.
% Welcome to find bugs,suggest improvements, and discuss with the author
%
% Xiang Wu     https://sites.google.com/site/rwfwuwx/Home/mfeeg
%              rwfwuwx@gmail.com    
%-------------------------------------------------------------------------

if nargin~=12
    disp('mf_epotf_get_singleTrialValue requires 12 arguments!');
    return;
end

[m,n,o] = size(epo);
tfValue = zeros(m,length(ch_interest));

if tf_type == 2 % for tfnpltwo, subtract erp from single trial
    erp = mf_epoavg(epo);
    eponoerp = zeros(m,n,o);
    for i = 1:o
        for j = 1:m
            eponoerp(j,:,i) = epo(j,:,i) - erp(i,:);
        end
    end
    
    epo = eponoerp;
    clear eponoerp;
end

for i=1:length(ch_interest)
    for j=1:m
        temp_tf = mf_tfcm( epo(j,:,ch_interest(i)),ncw_init,freq_interest,fs,is_vary_ncw,ncw_step,E_type );
        temp_tf_norm = mf_matrix_norm( temp_tf,base,norm_method );
        tfValue(j,i) = mean(mean(temp_tf_norm(:,time_interest)));
    end
end



