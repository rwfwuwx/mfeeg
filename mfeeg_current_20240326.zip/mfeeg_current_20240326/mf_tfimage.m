


function mf_tfimage(A1,sr,alltime,disptime,freq,freq_disp,ch_bad,is_scale_tf,freq_range_av,time_range_av)
%input for example;
% sr=1000; sample rate;
% alltime=[-300,800];whole time;
% disptime=[-100,600];display time;
% ch_bad=[];
% freq = 1:100; whole frequency
% freq_disp = 1:100;display freq
% is_scale_tf=0;



load biosemi_ch64_pos_2D;
load biosemi_ch64_label;

%%%%% time and freq 
time = (alltime(1):alltime(2))*(1/sr); % all time
time_disp = (disptime(1):disptime(2))*(1/sr); % time to be displayed
time_disp_lim = [time_disp(1),time_disp(length(time_disp))]; 
time_disp_init_point = find( time==time_disp(1) );					% point for cut data amsrording to 
time_disp_end_point = find( time==time_disp(length(time_disp)) );	% 	time_disp and freq_disp

 
freq_disp_lim = [freq_disp(1),freq_disp(length(freq_disp))];
freq_disp_init_point = find( freq==freq_disp(1) );
freq_disp_end_point = find( freq==freq_disp(length(freq_disp)) );


bb1 = A1;
bb1(:,:,ch_bad) = 0;
bb1 = bb1( freq_disp_init_point:freq_disp_end_point,time_disp_init_point:time_disp_end_point,: );

%most = max([max(abs(bb1(:))),max(abs(bb2(:)))]);
%
most = 5;
clim = [-most,most];
%
%
figure;
mf_drawtf(bb1,biosemi_ch64_pos_2D,biosemi_ch64_label,time_disp,freq_disp,clim,is_scale_tf);

% freq_range_av
% time_range_av
%% SCALP MAP
t1=A1;
time_window =[time_range_av(1):time_range_av(2)]*(1/sr); 
time_window_init_point = find( time==time_window(1) );					% point for cut data amsrording to 
time_window_end_point = find( time==time_window(end) );	% 	time_disp and freq_disp

freq_window=[freq_range_av(1):freq_range_av(2)];
freq_window_init_point=find( freq==freq_window(1) );
freq_window_end_point=find( freq==freq_window(end) );

t1=t1(freq_window_init_point:freq_window_end_point,time_window_init_point:time_window_end_point,:);
t11=mean(t1,1);
t12=mean(t11,2);

%��t12��ά
 aa=[];
for k=1:size(t12,3)
    a=t12(1,1,k);
    aa=[aa,a];
end

most = max(abs(aa(:)));
figure;

mf_topo2D(biosemi_ch64_pos_2D,[1:64],[1:64],aa,1,[-most,most]);
% mf_topo2D(biosemi_ch64_pos_2D,[1:64],[1:64],aa,1,[mapscale(1),mapscale(2)]);

end