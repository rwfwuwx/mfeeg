function reref_rawdata = mf_rawreref(rawdata,reref_ch)
%mf_rawreref re-referencing on rawdata
% Usage
%   reref_rawdata = mf_rawreref(rawdata,reref_ch)
% Input
%   reref_ch --- 
%       for seeg: ch num * reref_ch num. reref_ch num depends on reref method.
%           each row is a list reref_ch for the ch of the given row.
%       for eeg: simply a list reref_ch (i.e., no need of different reref_ch for different ch).
%           as a row vector.
% Description
%   for eeg, seeg, and different re-ref methods, 
%       1. it is the same to minus average signals of reref_ch from a ch, thus only one reref function.
%       2. it is the reref_ch, that is different. produce it differently before run mf_rawreref.
%           for seeg, use eleven_seeg_get_reref_ch
%           for eeg, simply input a list reref_ch; no need of extra function to produce reref_ch. 
% --- update history
% 2020-10-21 
%   add handling of scalp eeg. 
% 2020-05-28 initially written, for seeg

if nargin~=2
    disp('mf_rawreref requires 2 input arguments!')
	return
end

[m,n] = size(rawdata);
reref_rawdata = zeros(m,n);

for i=1:n
    if size(reref_ch,1)>1 % i.e., seeg, more than one row in reref_ch format
        tmp_data = rawdata(:,reref_ch(i,:));
    else % i.e., eeg, one row in reref_ch format
        tmp_data = rawdata(:,reref_ch);
    end
    reref_rawdata(:,i) = rawdata(:,i) - mean(tmp_data,2);
end

